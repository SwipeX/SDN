package org.test.ye.nop.u;

/**
 * Created with IntelliJ IDEA.
 * User: Tim
 * Date: 5/8/13
 * Time: 10:36 PM
 * To change this template use File | Settings | File Templates.
 */
public class allday {
}
