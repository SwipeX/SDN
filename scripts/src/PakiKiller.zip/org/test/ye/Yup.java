package org.test.ye;

import org.powerbuddy.script.Manifest;
import org.powerbuddy.script.Script;

/**
 * Created with IntelliJ IDEA.
 * User: Tim
 * Date: 5/8/13
 * Time: 10:36 PM
 * To change this template use File | Settings | File Templates.
 */
@Manifest(author = "Coke",name="PakiKiller",description = "Kills pakis",version = 1.0)
public class Yup extends Script {
    @Override
    public void onStart() {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public int loop() {
        return 0;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void onEnd() {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
